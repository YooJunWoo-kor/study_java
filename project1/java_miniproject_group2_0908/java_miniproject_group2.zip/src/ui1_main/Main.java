package ui1_main;

public class Main {
    public static void main(String[] args) {
        
        new StartFrame();
        
    }
    
}
